-- Create portfolio_videos table
CREATE TABLE IF NOT EXISTS public.portfolio_videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  youtube_url TEXT NOT NULL,
  thumbnail_url TEXT,
  category TEXT NOT NULL DEFAULT 'Geral',
  display_order INTEGER NOT NULL DEFAULT 0,
  is_published BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.portfolio_videos ENABLE ROW LEVEL SECURITY;

-- Anyone can read published videos
CREATE POLICY "Public can view published videos"
  ON public.portfolio_videos
  FOR SELECT
  USING (is_published = true);

-- Only authenticated admins can manage videos
-- Admin is determined by email match in application layer
CREATE POLICY "Admins can manage videos"
  ON public.portfolio_videos
  FOR ALL
  USING (auth.role() = 'authenticated')
  WITH CHECK (auth.role() = 'authenticated');

-- Trigger to update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_portfolio_videos_updated_at
  BEFORE UPDATE ON public.portfolio_videos
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert sample videos
INSERT INTO public.portfolio_videos (title, description, youtube_url, category, display_order) VALUES
  ('Highlights Carnaval 2024', 'Edição cinematográfica dos melhores momentos do carnaval com grade de cor profissional e motion graphics.', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'Carnaval', 1),
  ('Casamento Ana & Pedro', 'Trailer emocionante com trilha personalizada, transições fluidas e cor cinematic.', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'Casamento', 2),
  ('Spot Publicitário - Marca X', 'Edição de comercial com ritmo dinâmico, gráficos animados e acabamento broadcast.', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'Publicidade', 3);
