-- Create enum for product types
CREATE TYPE public.product_type AS ENUM ('arsenal_secreto', 'treino_intensivo');

-- Create table to track user product access
CREATE TABLE public.user_products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    product_type product_type NOT NULL,
    purchased_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    expires_at TIMESTAMP WITH TIME ZONE, -- NULL means never expires
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, product_type)
);

-- Enable RLS
ALTER TABLE public.user_products ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own products
CREATE POLICY "Users can view their own products"
ON public.user_products
FOR SELECT
USING (auth.uid() = user_id);

-- Policy: Only service role can insert/update (via webhook)
-- Users cannot insert/update their own product access
CREATE POLICY "Service role can manage products"
ON public.user_products
FOR ALL
USING (auth.role() = 'service_role')
WITH CHECK (auth.role() = 'service_role');

-- Add trigger for updated_at
CREATE TRIGGER update_user_products_updated_at
BEFORE UPDATE ON public.user_products
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create helper function to check product access
CREATE OR REPLACE FUNCTION public.has_product_access(_user_id UUID, _product product_type)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM public.user_products
        WHERE user_id = _user_id
          AND product_type = _product
          AND is_active = true
          AND (expires_at IS NULL OR expires_at > now())
    )
$$;