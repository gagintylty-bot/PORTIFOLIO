-- Create profiles table
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    email TEXT NOT NULL,
    full_name TEXT,
    is_premium BOOLEAN NOT NULL DEFAULT false,
    premium_activated_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create contents table for premium content
CREATE TABLE public.contents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    content_type TEXT NOT NULL DEFAULT 'article',
    content_body TEXT,
    video_url TEXT,
    display_order INTEGER NOT NULL DEFAULT 0,
    is_published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contents ENABLE ROW LEVEL SECURITY;

-- Profiles policies: Users can only view and update their own profile
CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Contents policies: Only premium users can view content
CREATE POLICY "Premium users can view published content" 
ON public.contents 
FOR SELECT 
USING (
    is_published = true 
    AND EXISTS (
        SELECT 1 FROM public.profiles 
        WHERE profiles.user_id = auth.uid() 
        AND profiles.is_premium = true
    )
);

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (user_id, email, full_name)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', '')
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for new user signup
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_contents_updated_at
    BEFORE UPDATE ON public.contents
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample premium content
INSERT INTO public.contents (title, description, content_type, content_body, display_order) VALUES
('Guia Completo de Leitura Corporal', 'Aprenda a interpretar os sinais não-verbais que revelam interesse genuíno.', 'article', 'O corpo fala antes das palavras. Quando uma mulher está genuinamente interessada, ela demonstra através de micro-expressões e posturas específicas...', 1),
('O Poder do Silêncio Estratégico', 'Descubra como o silêncio bem calibrado aumenta sua presença e valor percebido.', 'article', 'O homem sábio fala quando tem algo a dizer, não quando precisa dizer algo. O silêncio cria espaço para o mistério...', 2),
('Abordagens Naturais no Carnaval', 'Contextos e frases que abrem conversas de forma genuína e sem pressão.', 'article', 'A melhor abordagem não parece uma abordagem. Ela flui naturalmente do contexto...', 3),
('Quando Avançar e Quando Recuar', 'O timing perfeito é a arte de sentir o momento certo para cada movimento.', 'article', 'Avançar no momento errado demonstra desespero. Recuar no momento certo demonstra valor...', 4),
('Mentalidade de Abundância', 'Como cultivar a tranquilidade interior que naturalmente atrai.', 'article', 'A abundância não vem de ter muitas opções, mas de não precisar de nenhuma específica...', 5);