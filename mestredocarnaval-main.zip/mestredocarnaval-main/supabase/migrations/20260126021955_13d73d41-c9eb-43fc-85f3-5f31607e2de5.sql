-- Create community messages table for Treino Intensivo
CREATE TABLE public.community_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  user_name TEXT NOT NULL,
  message TEXT NOT NULL,
  product_type TEXT NOT NULL DEFAULT 'treino_intensivo',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.community_messages ENABLE ROW LEVEL SECURITY;

-- Users with product access can view messages
CREATE POLICY "Users with product access can view messages"
ON public.community_messages
FOR SELECT
USING (
  public.has_product_access(auth.uid(), product_type::product_type)
);

-- Users with product access can insert messages
CREATE POLICY "Users with product access can insert messages"
ON public.community_messages
FOR INSERT
WITH CHECK (
  auth.uid() = user_id AND
  public.has_product_access(auth.uid(), product_type::product_type)
);

-- Enable realtime for live updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.community_messages;

-- Create index for faster queries
CREATE INDEX idx_community_messages_product_type ON public.community_messages(product_type);
CREATE INDEX idx_community_messages_created_at ON public.community_messages(created_at DESC);