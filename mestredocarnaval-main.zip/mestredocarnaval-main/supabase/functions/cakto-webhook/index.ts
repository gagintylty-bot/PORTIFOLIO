import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-webhook-secret",
};

interface CaktoWebhookPayload {
  event: string;
  customer: {
    email: string;
    name?: string;
    phone?: string;
  };
  product?: {
    id: string;
    name: string;
  };
  transaction?: {
    id: string;
    status: string;
  };
}

// Product ID mapping - update these with your actual Cakto product IDs
const PRODUCT_MAPPING: Record<string, 'arsenal_secreto' | 'treino_intensivo' | 'main'> = {
  // Main product (Rei Salomão do Carnaval)
  "qd5jb69_729451": "main",
  // Arsenal Secreto order bump - add actual product ID from Cakto
  "arsenal_secreto_product_id": "arsenal_secreto",
  // Treino Intensivo order bump - add actual product ID from Cakto
  "treino_intensivo_product_id": "treino_intensivo",
};

// Alternative: Check by product name keywords
function detectProductType(productId?: string, productName?: string): ('arsenal_secreto' | 'treino_intensivo' | 'main')[] {
  const products: ('arsenal_secreto' | 'treino_intensivo' | 'main')[] = [];
  
  // Check by product ID first
  if (productId && PRODUCT_MAPPING[productId]) {
    products.push(PRODUCT_MAPPING[productId]);
  }
  
  // Check by product name keywords
  if (productName) {
    const nameLower = productName.toLowerCase();
    
    if (nameLower.includes('arsenal') || nameLower.includes('secreto')) {
      if (!products.includes('arsenal_secreto')) {
        products.push('arsenal_secreto');
      }
    }
    
    if (nameLower.includes('treino') || nameLower.includes('intensivo')) {
      if (!products.includes('treino_intensivo')) {
        products.push('treino_intensivo');
      }
    }
    
    if (nameLower.includes('rei') || nameLower.includes('salomão') || nameLower.includes('carnaval')) {
      if (!products.includes('main')) {
        products.push('main');
      }
    }
  }
  
  // Default to main product if nothing detected
  if (products.length === 0) {
    products.push('main');
  }
  
  return products;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // === DETAILED LOGGING FOR DEBUGGING ===
    console.log("=== WEBHOOK REQUEST RECEIVED ===");
    console.log("Method:", req.method);
    console.log("URL:", req.url);

    // Log all headers (mask sensitive values)
    const headersList: Record<string, string> = {};
    req.headers.forEach((value, key) => {
      if (key.toLowerCase().includes('secret') || key.toLowerCase().includes('auth')) {
        headersList[key] = value ? `${value.substring(0, 8)}...` : 'empty';
      } else {
        headersList[key] = value;
      }
    });
    console.log("All Headers:", JSON.stringify(headersList, null, 2));

    // Validate webhook secret
    const webhookSecret = req.headers.get("x-webhook-secret");
    const expectedSecret = Deno.env.get("CAKTO_WEBHOOK_SECRET");

    // Log secret comparison details
    console.log("=== SECRET VALIDATION ===");
    console.log("Header 'x-webhook-secret' received:", webhookSecret ? `${webhookSecret.substring(0, 8)}... (length: ${webhookSecret.length})` : "NULL/EMPTY");
    console.log("Expected secret (first 8 chars):", expectedSecret ? `${expectedSecret.substring(0, 8)}... (length: ${expectedSecret.length})` : "NOT_CONFIGURED");
    console.log("Secrets match exactly:", webhookSecret === expectedSecret);
    
    // Check for common issues
    if (webhookSecret && expectedSecret) {
      console.log("Trimmed comparison:", webhookSecret.trim() === expectedSecret.trim());
      console.log("Lowercase comparison:", webhookSecret.toLowerCase() === expectedSecret.toLowerCase());
    }

    if (!expectedSecret) {
      console.error("CAKTO_WEBHOOK_SECRET not configured");
      return new Response(
        JSON.stringify({ error: "Webhook secret not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (webhookSecret !== expectedSecret) {
      console.error("Invalid webhook secret provided");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse request body
    const payload: CaktoWebhookPayload = await req.json();
    console.log("Received Cakto webhook:", JSON.stringify(payload, null, 2));

    // Only process purchase_approved events
    if (payload.event !== "purchase_approved") {
      console.log(`Ignoring event: ${payload.event}`);
      return new Response(
        JSON.stringify({ message: `Event ${payload.event} ignored` }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate customer email
    const customerEmail = payload.customer?.email?.toLowerCase().trim();
    if (!customerEmail) {
      console.error("No customer email in payload");
      return new Response(
        JSON.stringify({ error: "Customer email required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Detect which products were purchased
    const purchasedProducts = detectProductType(payload.product?.id, payload.product?.name);
    console.log("Detected products:", purchasedProducts);

    // Initialize Supabase client with service role
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Find user profile by email
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("email", customerEmail)
      .maybeSingle();

    if (profileError) {
      console.error("Error fetching profile:", profileError);
      return new Response(
        JSON.stringify({ error: "Database error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!profile) {
      console.log(`No profile found for email: ${customerEmail}. User needs to sign up first.`);
      return new Response(
        JSON.stringify({ 
          message: "Purchase recorded. User needs to sign up with this email to activate premium.",
          email: customerEmail,
          products: purchasedProducts
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const activatedProducts: string[] = [];

    // Process each purchased product
    for (const productType of purchasedProducts) {
      if (productType === 'main') {
        // Update profile to premium for main product
        const { error: updateError } = await supabase
          .from("profiles")
          .update({
            is_premium: true,
            premium_activated_at: new Date().toISOString(),
          })
          .eq("id", profile.id);

        if (updateError) {
          console.error("Error updating profile to premium:", updateError);
        } else {
          console.log(`Activated premium for user: ${customerEmail}`);
          activatedProducts.push('main_premium');
        }
      } else {
        // Insert into user_products for order bump products
        // Check if already has this product
        const { data: existingProduct } = await supabase
          .from("user_products")
          .select("id")
          .eq("user_id", profile.user_id)
          .eq("product_type", productType)
          .maybeSingle();

        if (existingProduct) {
          console.log(`User already has ${productType}, updating to active`);
          const { error: updateError } = await supabase
            .from("user_products")
            .update({
              is_active: true,
              purchased_at: new Date().toISOString(),
            })
            .eq("id", existingProduct.id);

          if (updateError) {
            console.error(`Error updating ${productType}:`, updateError);
          } else {
            activatedProducts.push(productType);
          }
        } else {
          console.log(`Adding ${productType} for user: ${customerEmail}`);
          const { error: insertError } = await supabase
            .from("user_products")
            .insert({
              user_id: profile.user_id,
              product_type: productType,
              is_active: true,
              purchased_at: new Date().toISOString(),
            });

          if (insertError) {
            console.error(`Error inserting ${productType}:`, insertError);
          } else {
            activatedProducts.push(productType);
          }
        }
      }
    }

    console.log(`Successfully activated products for user ${customerEmail}:`, activatedProducts);
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Products activated successfully",
        email: customerEmail,
        activated_products: activatedProducts
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Webhook error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
