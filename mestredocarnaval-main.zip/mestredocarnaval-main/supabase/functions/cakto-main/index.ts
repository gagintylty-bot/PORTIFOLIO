import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-webhook-secret",
};

// Webhook secret for Rei Salomão do Carnaval (main product)
const WEBHOOK_SECRET = "a02e3a50-327e-448f-8dea-f576ee4ce13b";

interface CaktoWebhookPayload {
  event: string;
  customer: {
    email: string;
    name?: string;
    phone?: string;
  };
  product?: {
    id: string;
    name: string;
  };
  transaction?: {
    id: string;
    status: string;
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("=== CAKTO-MAIN WEBHOOK (Rei Salomão) ===");
    console.log("Method:", req.method);

    // Validate webhook secret
    const webhookSecret = req.headers.get("x-webhook-secret");
    
    console.log("Received secret:", webhookSecret ? `${webhookSecret.substring(0, 8)}...` : "EMPTY");
    console.log("Expected secret:", `${WEBHOOK_SECRET.substring(0, 8)}...`);
    console.log("Match:", webhookSecret === WEBHOOK_SECRET);

    if (webhookSecret !== WEBHOOK_SECRET) {
      console.error("Invalid webhook secret");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const payload: CaktoWebhookPayload = await req.json();
    console.log("Payload:", JSON.stringify(payload, null, 2));

    if (payload.event !== "purchase_approved") {
      console.log(`Ignoring event: ${payload.event}`);
      return new Response(
        JSON.stringify({ message: `Event ${payload.event} ignored` }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const customerEmail = payload.customer?.email?.toLowerCase().trim();
    if (!customerEmail) {
      console.error("No customer email");
      return new Response(
        JSON.stringify({ error: "Customer email required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Find profile by email
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("email", customerEmail)
      .maybeSingle();

    if (profileError) {
      console.error("Error fetching profile:", profileError);
      return new Response(
        JSON.stringify({ error: "Database error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!profile) {
      console.log(`No profile found for: ${customerEmail}`);
      return new Response(
        JSON.stringify({ 
          message: "User needs to sign up first",
          email: customerEmail
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Activate premium for main product
    const { error: updateError } = await supabase
      .from("profiles")
      .update({
        is_premium: true,
        premium_activated_at: new Date().toISOString(),
      })
      .eq("id", profile.id);

    if (updateError) {
      console.error("Error updating profile:", updateError);
      return new Response(
        JSON.stringify({ error: "Failed to activate premium" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`✅ Premium activated for: ${customerEmail}`);
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Premium activated",
        email: customerEmail
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Webhook error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
