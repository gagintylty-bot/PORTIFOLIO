import { useEffect, useRef } from "react";
import { ChevronDown } from "lucide-react";

export default function PortfolioHero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Subtle film grain effect
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;

    const draw = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      const imageData = ctx.createImageData(canvas.width, canvas.height);
      const data = imageData.data;
      for (let i = 0; i < data.length; i += 4) {
        const v = Math.random() * 20;
        data[i] = v;
        data[i + 1] = v;
        data[i + 2] = v;
        data[i + 3] = 18;
      }
      ctx.putImageData(imageData, 0, 0);
      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black">
      {/* Cinematic gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-charcoal to-black" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_hsl(43_74%_49%_/_0.08)_0%,_transparent_65%)]" />

      {/* Film grain canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none opacity-40"
      />

      {/* Letterbox bars */}
      <div className="absolute top-0 left-0 right-0 h-[6vh] bg-black z-10" />
      <div className="absolute bottom-0 left-0 right-0 h-[6vh] bg-black z-10" />

      {/* Content */}
      <div className="relative z-20 text-center px-6 max-w-5xl mx-auto">
        <p className="text-gold/80 tracking-[0.4em] uppercase text-xs md:text-sm font-body mb-6 animate-fade-in">
          Editor de Vídeo Profissional
        </p>

        <h1 className="font-display text-6xl md:text-8xl lg:text-[110px] text-cream leading-none tracking-tight mb-6">
          Mestre do{" "}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold to-gold-light">
            Carnaval
          </span>
        </h1>

        <p className="font-body text-cream/60 text-base md:text-xl max-w-2xl mx-auto leading-relaxed mb-10">
          Transformo momentos em obras-primas visuais. Edição cinematográfica com{" "}
          <span className="text-gold">grade de cor profissional</span>, motion graphics e trilha sonora perfeita.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => document.getElementById("portfolio")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3.5 bg-gold text-black font-body font-semibold tracking-widest uppercase text-sm hover:bg-gold-light transition-all duration-300 hover:scale-105"
          >
            Ver Portfólio
          </button>
          <button
            onClick={() => document.getElementById("contato")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3.5 border border-gold/40 text-cream/80 font-body tracking-widest uppercase text-sm hover:border-gold hover:text-cream transition-all duration-300"
          >
            Entre em Contato
          </button>
        </div>

        {/* Stats */}
        <div className="mt-16 flex justify-center gap-12 md:gap-20">
          {[
            { value: "100+", label: "Projetos" },
            { value: "5+", label: "Anos de Exp." },
            { value: "50+", label: "Clientes" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="font-display text-3xl md:text-4xl text-gold">{stat.value}</p>
              <p className="text-cream/50 text-xs tracking-widest uppercase mt-1 font-body">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 animate-bounce">
        <ChevronDown className="w-5 h-5 text-gold/50" />
      </div>
    </section>
  );
}
