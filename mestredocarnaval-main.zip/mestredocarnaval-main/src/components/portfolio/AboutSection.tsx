import { Camera, Film, Music, Zap } from "lucide-react";

const skills = [
  { icon: Film, label: "Edição Cinematográfica", desc: "Premiere Pro, DaVinci Resolve, Final Cut" },
  { icon: Camera, label: "Grade de Cor", desc: "Color grading profissional broadcast" },
  { icon: Music, label: "Design Sonoro", desc: "Mixagem, trilha e SFX personalizados" },
  { icon: Zap, label: "Motion Graphics", desc: "After Effects, animações e títulos" },
];

export default function AboutSection() {
  return (
    <section id="sobre" className="py-24 px-6 bg-charcoal/50">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: text */}
          <div>
            <p className="text-gold/80 tracking-[0.4em] uppercase text-xs font-body mb-3">
              Quem Sou Eu
            </p>
            <h2 className="font-display text-4xl md:text-5xl text-cream mb-6 leading-tight">
              Editor apaixonado por{" "}
              <span className="text-gold">contar histórias</span>{" "}
              em movimento
            </h2>
            <p className="text-cream/60 font-body leading-relaxed mb-4">
              Há mais de 5 anos transformo imagens brutas em narrativas visuais que emocionam,
              engajam e convertem. Especialista em eventos como carnaval, casamentos e conteúdo
              digital de alto impacto.
            </p>
            <p className="text-cream/60 font-body leading-relaxed mb-8">
              Cada corte é intencional. Cada transição conta uma história. Cada projeto é tratado
              com o cuidado de uma obra-prima — porque seu momento merece ser eterno.
            </p>

            <div className="flex gap-8">
              {[
                { value: "100+", label: "Projetos" },
                { value: "50+", label: "Clientes" },
                { value: "5+", label: "Anos" },
              ].map((s) => (
                <div key={s.label}>
                  <p className="font-display text-3xl text-gold">{s.value}</p>
                  <p className="text-cream/50 text-xs tracking-wider uppercase font-body mt-1">{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: skills */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {skills.map(({ icon: Icon, label, desc }) => (
              <div
                key={label}
                className="p-5 bg-charcoal border border-border hover:border-gold/30 transition-colors duration-300 group"
              >
                <Icon className="w-6 h-6 text-gold mb-3 group-hover:scale-110 transition-transform" />
                <h3 className="font-display text-base text-cream mb-1">{label}</h3>
                <p className="text-cream/50 text-xs font-body leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
