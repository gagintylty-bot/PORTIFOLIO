import { Mail, Instagram, MessageCircle, ArrowRight } from "lucide-react";

export default function ContactSection() {
  return (
    <section id="contato" className="py-24 px-6 bg-charcoal/50">
      <div className="max-w-4xl mx-auto text-center">
        <p className="text-gold/80 tracking-[0.4em] uppercase text-xs font-body mb-3">
          Vamos Trabalhar Juntos
        </p>
        <h2 className="font-display text-4xl md:text-6xl text-cream mb-6">
          Entre em Contato
        </h2>
        <div className="w-16 h-px bg-gold mx-auto mb-8" />

        <p className="text-cream/60 font-body leading-relaxed max-w-xl mx-auto mb-12">
          Tem um projeto em mente? Vamos transformar sua visão em realidade.
          Entre em contato e receba um orçamento personalizado.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <a
            href="mailto:contato@mestredocarnaval.com"
            className="group flex items-center justify-center gap-3 px-8 py-4 bg-gold text-black font-body font-semibold tracking-wider uppercase text-sm hover:bg-gold-light transition-all duration-300 hover:scale-105"
          >
            <Mail className="w-4 h-4" />
            Enviar Email
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
          <a
            href="https://wa.me/5511999999999"
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center justify-center gap-3 px-8 py-4 border border-gold/40 text-cream/80 font-body tracking-wider uppercase text-sm hover:border-gold hover:text-cream transition-all duration-300"
          >
            <MessageCircle className="w-4 h-4 text-gold" />
            WhatsApp
          </a>
        </div>

        <div className="flex justify-center gap-6">
          <a
            href="https://instagram.com/mestredocarnaval"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-cream/40 hover:text-gold transition-colors duration-300 text-sm font-body"
          >
            <Instagram className="w-4 h-4" />
            @mestredocarnaval
          </a>
        </div>
      </div>
    </section>
  );
}
