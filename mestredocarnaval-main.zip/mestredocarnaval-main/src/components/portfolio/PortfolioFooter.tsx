import { Film } from "lucide-react";

export default function PortfolioFooter() {
  return (
    <footer className="py-8 px-6 bg-black border-t border-border">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Film className="w-4 h-4 text-gold" />
          <span className="font-display text-cream/70 tracking-widest uppercase text-sm">
            Mestre do Carnaval
          </span>
        </div>
        <p className="text-cream/30 text-xs font-body tracking-wider">
          © {new Date().getFullYear()} — Editor de Vídeo Profissional
        </p>
      </div>
    </footer>
  );
}
