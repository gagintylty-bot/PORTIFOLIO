import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import VideoCard from "./VideoCard";
import { Loader2 } from "lucide-react";

interface Video {
  id: string;
  title: string;
  description: string | null;
  youtube_url: string;
  thumbnail_url: string | null;
  category: string;
  display_order: number;
}

export default function VideoGrid() {
  const [activeCategory, setActiveCategory] = useState("Todos");

  const { data: videos = [], isLoading } = useQuery({
    queryKey: ["portfolio_videos"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("portfolio_videos")
        .select("*")
        .eq("is_published", true)
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as Video[];
    },
  });

  const categories = ["Todos", ...Array.from(new Set(videos.map((v) => v.category)))];

  const filtered =
    activeCategory === "Todos"
      ? videos
      : videos.filter((v) => v.category === activeCategory);

  return (
    <section id="portfolio" className="py-24 px-6 bg-black">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16">
          <p className="text-gold/80 tracking-[0.4em] uppercase text-xs font-body mb-3">
            Meu Trabalho
          </p>
          <h2 className="font-display text-4xl md:text-6xl text-cream">
            Portfólio
          </h2>
          <div className="w-16 h-px bg-gold mx-auto mt-6" />
        </div>

        {/* Category filter */}
        {categories.length > 1 && (
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2 text-xs tracking-widest uppercase font-body transition-all duration-200 border ${
                  activeCategory === cat
                    ? "bg-gold text-black border-gold font-semibold"
                    : "border-border text-cream/60 hover:border-gold/40 hover:text-cream"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}

        {/* Grid */}
        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 text-gold animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 text-cream/40 font-body">
            Nenhum vídeo publicado ainda.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
