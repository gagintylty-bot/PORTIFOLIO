import { Film, Heart, Megaphone, Youtube, Clapperboard, Star } from "lucide-react";

const services = [
  {
    icon: Film,
    title: "Edição Cinematográfica",
    desc: "Transformo suas gravações em um filme de cinema. Grade de cor profissional, cortes precisos e narrativa envolvente.",
  },
  {
    icon: Heart,
    title: "Casamentos & Eventos",
    desc: "Trailer emocionante do seu dia especial. Capturo cada momento com sensibilidade e acabamento de alta qualidade.",
  },
  {
    icon: Clapperboard,
    title: "Carnaval & Festividades",
    desc: "Especialidade em edição de eventos culturais e carnavalescos. Energia, ritmo e a magia do Brasil na tela.",
  },
  {
    icon: Megaphone,
    title: "Publicidade & Comerciais",
    desc: "Spots publicitários que convertem. Edição dinâmica, gráficos animados e acabamento broadcast.",
  },
  {
    icon: Youtube,
    title: "Conteúdo para YouTube",
    desc: "Edição de vlogs, podcasts e conteúdo de criadores. Ritmo perfeito para manter o espectador engajado.",
  },
  {
    icon: Star,
    title: "Reels & Short-form",
    desc: "Vídeos curtos de alto impacto para Instagram, TikTok e YouTube Shorts que viralizam.",
  },
];

export default function ServicesSection() {
  return (
    <section id="servicos" className="py-24 px-6 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-gold/80 tracking-[0.4em] uppercase text-xs font-body mb-3">
            O Que Ofereço
          </p>
          <h2 className="font-display text-4xl md:text-6xl text-cream">
            Serviços
          </h2>
          <div className="w-16 h-px bg-gold mx-auto mt-6" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="group p-6 border border-border hover:border-gold/40 bg-charcoal/30 hover:bg-charcoal/60 transition-all duration-300"
            >
              <div className="w-10 h-10 flex items-center justify-center mb-4 border border-gold/30 group-hover:border-gold/60 group-hover:bg-gold/5 transition-all duration-300">
                <Icon className="w-5 h-5 text-gold" />
              </div>
              <h3 className="font-display text-xl text-cream mb-2 group-hover:text-gold transition-colors duration-300">
                {title}
              </h3>
              <p className="text-cream/50 text-sm font-body leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
