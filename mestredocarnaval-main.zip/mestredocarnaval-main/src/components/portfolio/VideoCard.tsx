import { useState } from "react";
import { Play, X } from "lucide-react";

interface Video {
  id: string;
  title: string;
  description: string | null;
  youtube_url: string;
  thumbnail_url: string | null;
  category: string;
}

function getYouTubeId(url: string): string {
  const patterns = [
    /youtu\.be\/([^?#]+)/,
    /youtube\.com\/watch\?v=([^&#]+)/,
    /youtube\.com\/embed\/([^?#]+)/,
    /youtube\.com\/shorts\/([^?#]+)/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return url;
}

function getYouTubeThumbnail(url: string): string {
  const id = getYouTubeId(url);
  return `https://img.youtube.com/vi/${id}/maxresdefault.jpg`;
}

export default function VideoCard({ video }: { video: Video }) {
  const [modalOpen, setModalOpen] = useState(false);
  const thumbnail = video.thumbnail_url || getYouTubeThumbnail(video.youtube_url);
  const videoId = getYouTubeId(video.youtube_url);

  return (
    <>
      <div
        className="group relative bg-charcoal border border-border hover:border-gold/40 transition-all duration-500 cursor-pointer overflow-hidden"
        onClick={() => setModalOpen(true)}
      >
        {/* Thumbnail */}
        <div className="relative aspect-video overflow-hidden">
          <img
            src={thumbnail}
            alt={video.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            onError={(e) => {
              (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
            }}
          />
          <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-colors duration-300" />

          {/* Play button */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-14 h-14 rounded-full border-2 border-white/80 flex items-center justify-center group-hover:border-gold group-hover:scale-110 transition-all duration-300 bg-black/20 backdrop-blur-sm">
              <Play className="w-5 h-5 text-white group-hover:text-gold fill-current ml-1" />
            </div>
          </div>

          {/* Category badge */}
          <span className="absolute top-3 left-3 text-[10px] tracking-widest uppercase font-body bg-gold/90 text-black px-2 py-1 font-semibold">
            {video.category}
          </span>
        </div>

        {/* Info */}
        <div className="p-4">
          <h3 className="font-display text-lg text-cream group-hover:text-gold transition-colors duration-300 leading-tight">
            {video.title}
          </h3>
          {video.description && (
            <p className="text-cream/50 text-xs font-body mt-1.5 line-clamp-2 leading-relaxed">
              {video.description}
            </p>
          )}
        </div>

        {/* Gold border reveal on hover */}
        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gold scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
      </div>

      {/* YouTube Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-sm p-4"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="relative w-full max-w-4xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setModalOpen(false)}
              className="absolute -top-10 right-0 text-cream/70 hover:text-white transition-colors flex items-center gap-2 text-sm font-body"
            >
              <X className="w-4 h-4" />
              Fechar
            </button>
            <div className="aspect-video w-full">
              <iframe
                className="w-full h-full"
                src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`}
                title={video.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
            <div className="mt-4">
              <h2 className="font-display text-xl text-cream">{video.title}</h2>
              {video.description && (
                <p className="text-cream/60 text-sm font-body mt-1">{video.description}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
