import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Menu, X, Film, LogIn, Settings } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

const ADMIN_EMAIL = import.meta.env.VITE_ADMIN_EMAIL;

export default function PortfolioNavbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const isAdmin = user?.email === ADMIN_EMAIL || user?.email === "gagintylty@gmail.com";

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id: string) => {
    setMobileOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-black/90 backdrop-blur-md border-b border-gold/20 py-3"
          : "bg-transparent py-6"
      }`}
    >
      <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <Film className="w-5 h-5 text-gold group-hover:rotate-12 transition-transform" />
          <span className="font-display text-xl text-cream tracking-widest uppercase">
            Mestre do Carnaval
          </span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {[
            { label: "Portfólio", id: "portfolio" },
            { label: "Sobre", id: "sobre" },
            { label: "Serviços", id: "servicos" },
            { label: "Contato", id: "contato" },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className="text-sm text-cream/70 hover:text-gold transition-colors tracking-wider uppercase font-body"
            >
              {item.label}
            </button>
          ))}

          {isAdmin && (
            <Button
              size="sm"
              variant="outline"
              className="border-gold/50 text-gold hover:bg-gold/10 gap-2"
              onClick={() => navigate("/admin")}
            >
              <Settings className="w-3.5 h-3.5" />
              Admin
            </Button>
          )}

          {user ? (
            <button
              onClick={() => signOut()}
              className="text-sm text-cream/50 hover:text-cream transition-colors tracking-wider uppercase font-body"
            >
              Sair
            </button>
          ) : (
            <button
              onClick={() => navigate("/auth")}
              className="flex items-center gap-1.5 text-sm text-cream/50 hover:text-gold transition-colors"
            >
              <LogIn className="w-4 h-4" />
              <span className="tracking-wider uppercase font-body">Entrar</span>
            </button>
          )}
        </nav>

        {/* Mobile hamburger */}
        <button
          className="md:hidden text-cream"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-black/95 border-t border-gold/20 px-6 py-4 flex flex-col gap-4">
          {[
            { label: "Portfólio", id: "portfolio" },
            { label: "Sobre", id: "sobre" },
            { label: "Serviços", id: "servicos" },
            { label: "Contato", id: "contato" },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className="text-left text-cream/70 hover:text-gold transition-colors tracking-wider uppercase font-body text-sm"
            >
              {item.label}
            </button>
          ))}
          {isAdmin && (
            <button
              onClick={() => { setMobileOpen(false); navigate("/admin"); }}
              className="text-left text-gold text-sm tracking-wider uppercase font-body flex items-center gap-2"
            >
              <Settings className="w-4 h-4" />
              Painel Admin
            </button>
          )}
          {user ? (
            <button
              onClick={() => { signOut(); setMobileOpen(false); }}
              className="text-left text-cream/50 text-sm tracking-wider uppercase font-body"
            >
              Sair
            </button>
          ) : (
            <button
              onClick={() => { navigate("/auth"); setMobileOpen(false); }}
              className="text-left text-cream/50 text-sm tracking-wider uppercase font-body"
            >
              Entrar
            </button>
          )}
        </div>
      )}
    </header>
  );
}
