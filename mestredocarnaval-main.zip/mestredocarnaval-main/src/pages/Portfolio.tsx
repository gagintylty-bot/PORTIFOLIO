import PortfolioNavbar from "@/components/portfolio/PortfolioNavbar";
import PortfolioHero from "@/components/portfolio/PortfolioHero";
import VideoGrid from "@/components/portfolio/VideoGrid";
import AboutSection from "@/components/portfolio/AboutSection";
import ServicesSection from "@/components/portfolio/ServicesSection";
import ContactSection from "@/components/portfolio/ContactSection";
import PortfolioFooter from "@/components/portfolio/PortfolioFooter";

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-black">
      <PortfolioNavbar />
      <PortfolioHero />
      <VideoGrid />
      <AboutSection />
      <ServicesSection />
      <ContactSection />
      <PortfolioFooter />
    </div>
  );
}
