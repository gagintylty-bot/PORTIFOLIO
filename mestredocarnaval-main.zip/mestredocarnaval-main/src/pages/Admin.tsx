import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  Plus,
  Trash2,
  Edit3,
  Eye,
  EyeOff,
  Film,
  ArrowLeft,
  Save,
  X,
  GripVertical,
  Loader2,
} from "lucide-react";

const ADMIN_EMAIL = import.meta.env.VITE_ADMIN_EMAIL;

interface Video {
  id: string;
  title: string;
  description: string | null;
  youtube_url: string;
  thumbnail_url: string | null;
  category: string;
  display_order: number;
  is_published: boolean;
  created_at: string;
}

const emptyForm = {
  title: "",
  description: "",
  youtube_url: "",
  thumbnail_url: "",
  category: "Geral",
  display_order: 0,
  is_published: true,
};

export default function Admin() {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const isAdmin =
    user?.email === ADMIN_EMAIL || user?.email === "gagintylty@gmail.com";

  const [editingId, setEditingId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ ...emptyForm });

  const { data: videos = [], isLoading } = useQuery({
    queryKey: ["portfolio_videos_admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("portfolio_videos")
        .select("*")
        .order("display_order", { ascending: true });
      if (error) throw error;
      return data as Video[];
    },
    enabled: !!user && isAdmin,
  });

  const saveMutation = useMutation({
    mutationFn: async (data: typeof emptyForm & { id?: string }) => {
      const payload = {
        title: data.title,
        description: data.description || null,
        youtube_url: data.youtube_url,
        thumbnail_url: data.thumbnail_url || null,
        category: data.category,
        display_order: Number(data.display_order),
        is_published: data.is_published,
      };

      if (data.id) {
        const { error } = await supabase
          .from("portfolio_videos")
          .update(payload)
          .eq("id", data.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("portfolio_videos")
          .insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["portfolio_videos_admin"] });
      qc.invalidateQueries({ queryKey: ["portfolio_videos"] });
      toast.success(editingId ? "Vídeo atualizado!" : "Vídeo adicionado!");
      resetForm();
    },
    onError: (e) => {
      toast.error("Erro ao salvar: " + (e as Error).message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("portfolio_videos")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["portfolio_videos_admin"] });
      qc.invalidateQueries({ queryKey: ["portfolio_videos"] });
      toast.success("Vídeo removido!");
    },
    onError: (e) => {
      toast.error("Erro ao remover: " + (e as Error).message);
    },
  });

  const togglePublished = useMutation({
    mutationFn: async ({ id, is_published }: { id: string; is_published: boolean }) => {
      const { error } = await supabase
        .from("portfolio_videos")
        .update({ is_published })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["portfolio_videos_admin"] });
      qc.invalidateQueries({ queryKey: ["portfolio_videos"] });
    },
    onError: (e) => toast.error("Erro: " + (e as Error).message),
  });

  const resetForm = () => {
    setForm({ ...emptyForm });
    setEditingId(null);
    setShowForm(false);
  };

  const startEdit = (v: Video) => {
    setForm({
      title: v.title,
      description: v.description || "",
      youtube_url: v.youtube_url,
      thumbnail_url: v.thumbnail_url || "",
      category: v.category,
      display_order: v.display_order,
      is_published: v.is_published,
    });
    setEditingId(v.id);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim() || !form.youtube_url.trim()) {
      toast.error("Título e URL do YouTube são obrigatórios.");
      return;
    }
    saveMutation.mutate({ ...form, id: editingId || undefined });
  };

  // Auth guard
  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-gold animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center gap-4">
        <p className="text-cream/60 font-body">Você precisa fazer login para acessar esta área.</p>
        <Button onClick={() => navigate("/auth")} className="bg-gold text-black hover:bg-gold-light">
          Fazer Login
        </Button>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center gap-4">
        <p className="text-cream/60 font-body text-center max-w-sm">
          Acesso restrito. Esta área é exclusiva para o administrador do portfólio.
        </p>
        <Button variant="outline" onClick={() => navigate("/")} className="border-gold/40 text-gold hover:bg-gold/10">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Portfólio
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-cream">
      {/* Header */}
      <header className="border-b border-border bg-charcoal/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Film className="w-5 h-5 text-gold" />
            <span className="font-display text-lg tracking-wider">Painel Admin</span>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/")}
              className="text-cream/60 hover:text-cream gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Ver Portfólio
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={signOut}
              className="text-cream/40 hover:text-cream text-xs"
            >
              Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-10">
        {/* Add/Edit Form */}
        {showForm ? (
          <div className="mb-10 bg-charcoal border border-border p-6 rounded-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-2xl text-cream">
                {editingId ? "Editar Vídeo" : "Adicionar Novo Vídeo"}
              </h2>
              <button onClick={resetForm} className="text-cream/40 hover:text-cream">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-xs text-cream/50 uppercase tracking-wider mb-1.5 font-body">
                  Título *
                </label>
                <Input
                  value={form.title}
                  onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                  placeholder="Ex: Highlights Carnaval 2024"
                  className="bg-black border-border focus:border-gold text-cream"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs text-cream/50 uppercase tracking-wider mb-1.5 font-body">
                  URL do YouTube *
                </label>
                <Input
                  value={form.youtube_url}
                  onChange={(e) => setForm((f) => ({ ...f, youtube_url: e.target.value }))}
                  placeholder="https://www.youtube.com/watch?v=..."
                  className="bg-black border-border focus:border-gold text-cream"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-cream/50 uppercase tracking-wider mb-1.5 font-body">
                  Categoria
                </label>
                <Input
                  value={form.category}
                  onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                  placeholder="Ex: Carnaval, Casamento, Publicidade"
                  className="bg-black border-border focus:border-gold text-cream"
                />
              </div>

              <div>
                <label className="block text-xs text-cream/50 uppercase tracking-wider mb-1.5 font-body">
                  Ordem de exibição
                </label>
                <Input
                  type="number"
                  value={form.display_order}
                  onChange={(e) => setForm((f) => ({ ...f, display_order: Number(e.target.value) }))}
                  className="bg-black border-border focus:border-gold text-cream"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs text-cream/50 uppercase tracking-wider mb-1.5 font-body">
                  Descrição
                </label>
                <Textarea
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  placeholder="Descrição breve do projeto..."
                  rows={3}
                  className="bg-black border-border focus:border-gold text-cream resize-none"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs text-cream/50 uppercase tracking-wider mb-1.5 font-body">
                  URL da thumbnail personalizada (opcional)
                </label>
                <Input
                  value={form.thumbnail_url}
                  onChange={(e) => setForm((f) => ({ ...f, thumbnail_url: e.target.value }))}
                  placeholder="https://... (deixe vazio para usar thumbnail do YouTube)"
                  className="bg-black border-border focus:border-gold text-cream"
                />
              </div>

              <div className="md:col-span-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, is_published: !f.is_published }))}
                  className={`relative w-10 h-5 rounded-full transition-colors ${
                    form.is_published ? "bg-gold" : "bg-border"
                  }`}
                >
                  <span
                    className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                      form.is_published ? "translate-x-5" : "translate-x-0"
                    }`}
                  />
                </button>
                <span className="text-sm font-body text-cream/70">
                  {form.is_published ? "Publicado" : "Oculto"}
                </span>
              </div>

              <div className="md:col-span-2 flex gap-3 pt-2">
                <Button
                  type="submit"
                  disabled={saveMutation.isPending}
                  className="bg-gold text-black hover:bg-gold-light font-semibold gap-2"
                >
                  {saveMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  {editingId ? "Salvar Alterações" : "Adicionar Vídeo"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={resetForm}
                  className="border-border text-cream/60 hover:text-cream"
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </div>
        ) : (
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="font-display text-3xl text-cream">Meus Vídeos</h1>
              <p className="text-cream/40 text-sm font-body mt-1">
                {videos.length} vídeo{videos.length !== 1 ? "s" : ""} no portfólio
              </p>
            </div>
            <Button
              onClick={() => setShowForm(true)}
              className="bg-gold text-black hover:bg-gold-light font-semibold gap-2"
            >
              <Plus className="w-4 h-4" />
              Adicionar Vídeo
            </Button>
          </div>
        )}

        {/* Video list */}
        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 text-gold animate-spin" />
          </div>
        ) : videos.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-border rounded-sm">
            <Film className="w-10 h-10 text-cream/20 mx-auto mb-3" />
            <p className="text-cream/40 font-body">Nenhum vídeo ainda. Adicione o primeiro!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {videos.map((v) => (
              <div
                key={v.id}
                className={`flex items-center gap-4 p-4 border rounded-sm transition-colors ${
                  v.is_published
                    ? "border-border bg-charcoal/30"
                    : "border-border/40 bg-charcoal/10 opacity-60"
                }`}
              >
                <GripVertical className="w-4 h-4 text-cream/20 flex-shrink-0" />

                {/* Thumbnail */}
                <div className="w-20 aspect-video bg-black rounded-sm overflow-hidden flex-shrink-0">
                  <img
                    src={
                      v.thumbnail_url ||
                      `https://img.youtube.com/vi/${v.youtube_url.match(/(?:v=|youtu\.be\/)([^&#?]+)/)?.[1]}/mqdefault.jpg`
                    }
                    alt={v.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className="font-display text-base text-cream truncate">{v.title}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] bg-gold/20 text-gold px-1.5 py-0.5 rounded-sm font-body tracking-wider">
                      {v.category}
                    </span>
                    <span className="text-cream/30 text-xs font-body">ordem: {v.display_order}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    onClick={() => togglePublished.mutate({ id: v.id, is_published: !v.is_published })}
                    title={v.is_published ? "Ocultar" : "Publicar"}
                    className="p-1.5 text-cream/40 hover:text-gold transition-colors"
                  >
                    {v.is_published ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => startEdit(v)}
                    title="Editar"
                    className="p-1.5 text-cream/40 hover:text-gold transition-colors"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Remover "${v.title}"?`)) {
                        deleteMutation.mutate(v.id);
                      }
                    }}
                    title="Remover"
                    className="p-1.5 text-cream/40 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
