import Portfolio from "./Portfolio";

export default function Index() {
  return <Portfolio />;
}
